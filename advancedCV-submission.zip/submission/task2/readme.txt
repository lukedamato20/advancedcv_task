task2.ipynb contains the script we used for splitting the dataset and for augmentation.

retinanet-training.ipynb & yolov7-training.ipynb contain the script we used to train and test both models

